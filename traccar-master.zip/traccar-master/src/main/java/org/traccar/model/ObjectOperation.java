package org.traccar.model;

public enum ObjectOperation {
    ADD,
    UPDATE,
    DELETE,
}
